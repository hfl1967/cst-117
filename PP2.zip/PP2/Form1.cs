﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            // hold the selection from the contactListBox
            string selectedContact; // 

            // contact list box logic
            if (contactListBox.SelectedIndex != -1)
            {
                // get the contact
                selectedContact = contactListBox.SelectedItem.ToString();

                // determine the output for contact box
                switch (selectedContact)
                {
                    case "Known contact with COVID-19 patient.":
                        resultLabel3.Text = "14 day quarantine and begin contact chaining.";
                        break;
                    case "Contact with suspected COVID-19 patient.":
                        resultLabel3.Text = "14 day quarantine.";
                        break;
                    case "No known contact with COVID-19 patient.":
                        resultLabel3.Text = "Monitor symptoms IAW CDC website.";
                        break;
                }
            }
            else
            {
                // no contact selected
                MessageBox.Show("Please select nature of contact.");
            }

            // symptoms box logic
            if (feverCheckBox.Checked && coughCheckBox.Checked && breathingCheckBox.Checked)
            {
                resultLabel2.Text = "Go to the emergency room now.";
            }

            else if (feverCheckBox.Checked || coughCheckBox.Checked || acheCheckBox.Checked || breathingCheckBox.Checked || fatigueCheckBox.Checked || headacheCheckBox.Checked)
            {
                resultLabel2.Text = "Get tested.";
            }

            else
            {
                MessageBox.Show("Please reevaluate symptoms.");
            }

            // work location box logic
            if (hqRadioButton.Checked)
            {
                resultLabel.Text = "Notify HR immediately and begin telework.";
            }
            else
            {
                resultLabel.Text = "Notify HR and continue telework.";
            }
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            resultLabel.Text = "";
            resultLabel2.Text = "";
            resultLabel3.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }

       
}