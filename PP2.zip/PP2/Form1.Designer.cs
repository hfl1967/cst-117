﻿namespace PP2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hqRadioButton = new System.Windows.Forms.RadioButton();
            this.teleworkRadioButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.resultLabel = new System.Windows.Forms.Label();
            this.generateButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.feverCheckBox = new System.Windows.Forms.CheckBox();
            this.coughCheckBox = new System.Windows.Forms.CheckBox();
            this.breathingCheckBox = new System.Windows.Forms.CheckBox();
            this.fatigueCheckBox = new System.Windows.Forms.CheckBox();
            this.acheCheckBox = new System.Windows.Forms.CheckBox();
            this.headacheCheckBox = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.contactListBox = new System.Windows.Forms.ListBox();
            this.resultLabel2 = new System.Windows.Forms.Label();
            this.resultLabel3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // hqRadioButton
            // 
            this.hqRadioButton.AutoSize = true;
            this.hqRadioButton.Location = new System.Drawing.Point(20, 100);
            this.hqRadioButton.Name = "hqRadioButton";
            this.hqRadioButton.Size = new System.Drawing.Size(82, 17);
            this.hqRadioButton.TabIndex = 0;
            this.hqRadioButton.TabStop = true;
            this.hqRadioButton.Text = "Work at HQ";
            this.hqRadioButton.UseVisualStyleBackColor = true;
            // 
            // teleworkRadioButton
            // 
            this.teleworkRadioButton.AutoSize = true;
            this.teleworkRadioButton.Location = new System.Drawing.Point(20, 123);
            this.teleworkRadioButton.Name = "teleworkRadioButton";
            this.teleworkRadioButton.Size = new System.Drawing.Size(69, 17);
            this.teleworkRadioButton.TabIndex = 1;
            this.teleworkRadioButton.TabStop = true;
            this.teleworkRadioButton.Text = "Telework";
            this.teleworkRadioButton.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Work Location";
            // 
            // resultLabel
            // 
            this.resultLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLabel.Location = new System.Drawing.Point(20, 229);
            this.resultLabel.Name = "resultLabel";
            this.resultLabel.Size = new System.Drawing.Size(560, 53);
            this.resultLabel.TabIndex = 6;
            this.resultLabel.Text = "Click \'Generate Results\' to list instructions.";
            // 
            // generateButton
            // 
            this.generateButton.Location = new System.Drawing.Point(462, 187);
            this.generateButton.Name = "generateButton";
            this.generateButton.Size = new System.Drawing.Size(118, 23);
            this.generateButton.TabIndex = 7;
            this.generateButton.Text = "Generate Results";
            this.generateButton.UseVisualStyleBackColor = true;
            this.generateButton.Click += new System.EventHandler(this.generateButton_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(563, 34);
            this.label2.TabIndex = 8;
            this.label2.Text = "If you\'ve been feeling sick or had possible contact with a COVID-19 patient, plea" +
    "se fill out the form for our company policy direction.";
            // 
            // feverCheckBox
            // 
            this.feverCheckBox.AutoSize = true;
            this.feverCheckBox.Location = new System.Drawing.Point(143, 88);
            this.feverCheckBox.Name = "feverCheckBox";
            this.feverCheckBox.Size = new System.Drawing.Size(53, 17);
            this.feverCheckBox.TabIndex = 9;
            this.feverCheckBox.Text = "Fever";
            this.feverCheckBox.UseVisualStyleBackColor = true;
            // 
            // coughCheckBox
            // 
            this.coughCheckBox.AutoSize = true;
            this.coughCheckBox.Location = new System.Drawing.Point(143, 111);
            this.coughCheckBox.Name = "coughCheckBox";
            this.coughCheckBox.Size = new System.Drawing.Size(57, 17);
            this.coughCheckBox.TabIndex = 10;
            this.coughCheckBox.Text = "Cough";
            this.coughCheckBox.UseVisualStyleBackColor = true;
            // 
            // breathingCheckBox
            // 
            this.breathingCheckBox.AutoSize = true;
            this.breathingCheckBox.Location = new System.Drawing.Point(143, 134);
            this.breathingCheckBox.Name = "breathingCheckBox";
            this.breathingCheckBox.Size = new System.Drawing.Size(114, 17);
            this.breathingCheckBox.TabIndex = 11;
            this.breathingCheckBox.Text = "Difficulty Breathing";
            this.breathingCheckBox.UseVisualStyleBackColor = true;
            // 
            // fatigueCheckBox
            // 
            this.fatigueCheckBox.AutoSize = true;
            this.fatigueCheckBox.Location = new System.Drawing.Point(264, 89);
            this.fatigueCheckBox.Name = "fatigueCheckBox";
            this.fatigueCheckBox.Size = new System.Drawing.Size(61, 17);
            this.fatigueCheckBox.TabIndex = 12;
            this.fatigueCheckBox.Text = "Fatigue";
            this.fatigueCheckBox.UseVisualStyleBackColor = true;
            // 
            // acheCheckBox
            // 
            this.acheCheckBox.AutoSize = true;
            this.acheCheckBox.Location = new System.Drawing.Point(264, 112);
            this.acheCheckBox.Name = "acheCheckBox";
            this.acheCheckBox.Size = new System.Drawing.Size(83, 17);
            this.acheCheckBox.TabIndex = 13;
            this.acheCheckBox.Text = "Body Aches";
            this.acheCheckBox.UseVisualStyleBackColor = true;
            // 
            // headacheCheckBox
            // 
            this.headacheCheckBox.AutoSize = true;
            this.headacheCheckBox.Location = new System.Drawing.Point(264, 135);
            this.headacheCheckBox.Name = "headacheCheckBox";
            this.headacheCheckBox.Size = new System.Drawing.Size(76, 17);
            this.headacheCheckBox.TabIndex = 14;
            this.headacheCheckBox.Text = "Headache";
            this.headacheCheckBox.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(196, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Symptoms";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(448, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 16;
            this.label4.Text = "Contact";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(504, 472);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(366, 472);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(113, 23);
            this.clearButton.TabIndex = 18;
            this.clearButton.Text = "Clear Results";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // contactListBox
            // 
            this.contactListBox.FormattingEnabled = true;
            this.contactListBox.Items.AddRange(new object[] {
            "Known contact with COVID-19 patient.",
            "Contact with suspected COVID-19 patient.",
            "No known contact with COVID-19 patient."});
            this.contactListBox.Location = new System.Drawing.Point(353, 89);
            this.contactListBox.Name = "contactListBox";
            this.contactListBox.Size = new System.Drawing.Size(226, 56);
            this.contactListBox.TabIndex = 19;
            // 
            // resultLabel2
            // 
            this.resultLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLabel2.Location = new System.Drawing.Point(20, 310);
            this.resultLabel2.Name = "resultLabel2";
            this.resultLabel2.Size = new System.Drawing.Size(560, 53);
            this.resultLabel2.TabIndex = 20;
            // 
            // resultLabel3
            // 
            this.resultLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultLabel3.Location = new System.Drawing.Point(20, 391);
            this.resultLabel3.Name = "resultLabel3";
            this.resultLabel3.Size = new System.Drawing.Size(560, 53);
            this.resultLabel3.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 16);
            this.label5.TabIndex = 22;
            this.label5.Text = "Work Guidance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "Medical Guidance";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 375);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 16);
            this.label7.TabIndex = 24;
            this.label7.Text = "Contact Guidance";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 513);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.resultLabel3);
            this.Controls.Add(this.resultLabel2);
            this.Controls.Add(this.contactListBox);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.headacheCheckBox);
            this.Controls.Add(this.acheCheckBox);
            this.Controls.Add(this.fatigueCheckBox);
            this.Controls.Add(this.breathingCheckBox);
            this.Controls.Add(this.coughCheckBox);
            this.Controls.Add(this.feverCheckBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.generateButton);
            this.Controls.Add(this.resultLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.teleworkRadioButton);
            this.Controls.Add(this.hqRadioButton);
            this.Name = "Form1";
            this.Text = "Workplace Sick Leave Wizard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton hqRadioButton;
        private System.Windows.Forms.RadioButton teleworkRadioButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label resultLabel;
        private System.Windows.Forms.Button generateButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox feverCheckBox;
        private System.Windows.Forms.CheckBox coughCheckBox;
        private System.Windows.Forms.CheckBox breathingCheckBox;
        private System.Windows.Forms.CheckBox fatigueCheckBox;
        private System.Windows.Forms.CheckBox acheCheckBox;
        private System.Windows.Forms.CheckBox headacheCheckBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.ListBox contactListBox;
        private System.Windows.Forms.Label resultLabel2;
        private System.Windows.Forms.Label resultLabel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

