﻿using System;

namespace MilestoneProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.inventoryListBox = new System.Windows.Forms.ListBox();
            this.albumLabel = new System.Windows.Forms.Label();
            this.albumOutput = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.artistLabel = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.priceOutput = new System.Windows.Forms.Label();
            this.quantityOutput = new System.Windows.Forms.Label();
            this.artistOutput = new System.Windows.Forms.Label();
            this.categoryOutput = new System.Windows.Forms.Label();
            this.searchLabel = new System.Windows.Forms.Label();
            this.addItemButton = new System.Windows.Forms.Button();
            this.removeItemButton = new System.Windows.Forms.Button();
            this.restockItemButton = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.label_App_Title = new System.Windows.Forms.Label();
            this.sellItemButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inventoryListBox
            // 
            this.inventoryListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryListBox.FormattingEnabled = true;
            this.inventoryListBox.ItemHeight = 20;
            this.inventoryListBox.Location = new System.Drawing.Point(11, 376);
            this.inventoryListBox.Margin = new System.Windows.Forms.Padding(2);
            this.inventoryListBox.Name = "inventoryListBox";
            this.inventoryListBox.Size = new System.Drawing.Size(403, 224);
            this.inventoryListBox.TabIndex = 0;
            this.inventoryListBox.SelectedIndexChanged += new System.EventHandler(this.InventoryListBox_SelectedIndexChanged);
            // 
            // albumLabel
            // 
            this.albumLabel.AutoSize = true;
            this.albumLabel.BackColor = System.Drawing.Color.Transparent;
            this.albumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.albumLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.albumLabel.Location = new System.Drawing.Point(184, 150);
            this.albumLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.albumLabel.Name = "albumLabel";
            this.albumLabel.Size = new System.Drawing.Size(46, 16);
            this.albumLabel.TabIndex = 1;
            this.albumLabel.Text = "Album";
            // 
            // albumOutput
            // 
            this.albumOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.albumOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.albumOutput.Location = new System.Drawing.Point(234, 136);
            this.albumOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.albumOutput.Name = "albumOutput";
            this.albumOutput.Size = new System.Drawing.Size(180, 30);
            this.albumOutput.TabIndex = 2;
            this.albumOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.BackColor = System.Drawing.Color.Transparent;
            this.priceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.priceLabel.Location = new System.Drawing.Point(191, 190);
            this.priceLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(39, 16);
            this.priceLabel.TabIndex = 3;
            this.priceLabel.Text = "Price";
            // 
            // quantityLabel
            // 
            this.quantityLabel.AutoSize = true;
            this.quantityLabel.BackColor = System.Drawing.Color.Transparent;
            this.quantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantityLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.quantityLabel.Location = new System.Drawing.Point(174, 230);
            this.quantityLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.quantityLabel.Name = "quantityLabel";
            this.quantityLabel.Size = new System.Drawing.Size(56, 16);
            this.quantityLabel.TabIndex = 4;
            this.quantityLabel.Text = "Quantity";
            // 
            // artistLabel
            // 
            this.artistLabel.AutoSize = true;
            this.artistLabel.BackColor = System.Drawing.Color.Transparent;
            this.artistLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.artistLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.artistLabel.Location = new System.Drawing.Point(193, 110);
            this.artistLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.artistLabel.Name = "artistLabel";
            this.artistLabel.Size = new System.Drawing.Size(37, 16);
            this.artistLabel.TabIndex = 5;
            this.artistLabel.Text = "Artist";
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.BackColor = System.Drawing.Color.Transparent;
            this.categoryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.categoryLabel.Location = new System.Drawing.Point(167, 70);
            this.categoryLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(63, 16);
            this.categoryLabel.TabIndex = 6;
            this.categoryLabel.Text = "Category";
            // 
            // priceOutput
            // 
            this.priceOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.priceOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceOutput.Location = new System.Drawing.Point(234, 176);
            this.priceOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.priceOutput.Name = "priceOutput";
            this.priceOutput.Size = new System.Drawing.Size(180, 30);
            this.priceOutput.TabIndex = 7;
            this.priceOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // quantityOutput
            // 
            this.quantityOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.quantityOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quantityOutput.Location = new System.Drawing.Point(234, 216);
            this.quantityOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.quantityOutput.Name = "quantityOutput";
            this.quantityOutput.Size = new System.Drawing.Size(180, 30);
            this.quantityOutput.TabIndex = 8;
            this.quantityOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // artistOutput
            // 
            this.artistOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.artistOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.artistOutput.Location = new System.Drawing.Point(234, 96);
            this.artistOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.artistOutput.Name = "artistOutput";
            this.artistOutput.Size = new System.Drawing.Size(180, 30);
            this.artistOutput.TabIndex = 9;
            this.artistOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // categoryOutput
            // 
            this.categoryOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.categoryOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryOutput.Location = new System.Drawing.Point(234, 56);
            this.categoryOutput.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.categoryOutput.Name = "categoryOutput";
            this.categoryOutput.Size = new System.Drawing.Size(180, 30);
            this.categoryOutput.TabIndex = 10;
            this.categoryOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // searchLabel
            // 
            this.searchLabel.AutoSize = true;
            this.searchLabel.BackColor = System.Drawing.Color.Transparent;
            this.searchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchLabel.ForeColor = System.Drawing.Color.Black;
            this.searchLabel.Location = new System.Drawing.Point(11, 47);
            this.searchLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.searchLabel.Name = "searchLabel";
            this.searchLabel.Size = new System.Drawing.Size(132, 17);
            this.searchLabel.TabIndex = 12;
            this.searchLabel.Text = "Search Artist/Album";
            this.searchLabel.Click += new System.EventHandler(this.label_search_Click);
            // 
            // addItemButton
            // 
            this.addItemButton.BackColor = System.Drawing.Color.Silver;
            this.addItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addItemButton.Location = new System.Drawing.Point(11, 110);
            this.addItemButton.Margin = new System.Windows.Forms.Padding(2);
            this.addItemButton.Name = "addItemButton";
            this.addItemButton.Size = new System.Drawing.Size(110, 30);
            this.addItemButton.TabIndex = 13;
            this.addItemButton.Text = "Add";
            this.addItemButton.UseVisualStyleBackColor = false;
            this.addItemButton.Click += new System.EventHandler(this.AddItemButton_Click);
            // 
            // removeItemButton
            // 
            this.removeItemButton.BackColor = System.Drawing.Color.Silver;
            this.removeItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeItemButton.Location = new System.Drawing.Point(11, 150);
            this.removeItemButton.Margin = new System.Windows.Forms.Padding(2);
            this.removeItemButton.Name = "removeItemButton";
            this.removeItemButton.Size = new System.Drawing.Size(110, 30);
            this.removeItemButton.TabIndex = 14;
            this.removeItemButton.Text = "Remove";
            this.removeItemButton.UseVisualStyleBackColor = false;
            this.removeItemButton.Click += new System.EventHandler(this.RemoveItemButton_Click);
            // 
            // restockItemButton
            // 
            this.restockItemButton.BackColor = System.Drawing.Color.Silver;
            this.restockItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restockItemButton.Location = new System.Drawing.Point(11, 190);
            this.restockItemButton.Margin = new System.Windows.Forms.Padding(2);
            this.restockItemButton.Name = "restockItemButton";
            this.restockItemButton.Size = new System.Drawing.Size(110, 30);
            this.restockItemButton.TabIndex = 15;
            this.restockItemButton.Text = "Restock";
            this.restockItemButton.UseVisualStyleBackColor = false;
            this.restockItemButton.Click += new System.EventHandler(this.RestockItemButton_Click);
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(11, 76);
            this.txt_search.Margin = new System.Windows.Forms.Padding(2);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(111, 20);
            this.txt_search.TabIndex = 16;
            this.txt_search.TextChanged += new System.EventHandler(this.SearchTextChanged);
            // 
            // label_App_Title
            // 
            this.label_App_Title.AutoSize = true;
            this.label_App_Title.BackColor = System.Drawing.Color.Transparent;
            this.label_App_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_App_Title.ForeColor = System.Drawing.Color.Black;
            this.label_App_Title.Location = new System.Drawing.Point(72, 6);
            this.label_App_Title.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_App_Title.Name = "label_App_Title";
            this.label_App_Title.Size = new System.Drawing.Size(276, 31);
            this.label_App_Title.TabIndex = 18;
            this.label_App_Title.Text = "Mike\'s Vinyl Inventory";
            // 
            // sellItemButton
            // 
            this.sellItemButton.BackColor = System.Drawing.Color.Silver;
            this.sellItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sellItemButton.Location = new System.Drawing.Point(11, 230);
            this.sellItemButton.Margin = new System.Windows.Forms.Padding(2);
            this.sellItemButton.Name = "sellItemButton";
            this.sellItemButton.Size = new System.Drawing.Size(110, 30);
            this.sellItemButton.TabIndex = 19;
            this.sellItemButton.Text = "Sell";
            this.sellItemButton.UseVisualStyleBackColor = false;
            this.sellItemButton.Click += new System.EventHandler(this.SellItemButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(420, 612);
            this.Controls.Add(this.sellItemButton);
            this.Controls.Add(this.label_App_Title);
            this.Controls.Add(this.searchLabel);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.addItemButton);
            this.Controls.Add(this.restockItemButton);
            this.Controls.Add(this.categoryOutput);
            this.Controls.Add(this.removeItemButton);
            this.Controls.Add(this.artistOutput);
            this.Controls.Add(this.quantityOutput);
            this.Controls.Add(this.priceOutput);
            this.Controls.Add(this.categoryLabel);
            this.Controls.Add(this.artistLabel);
            this.Controls.Add(this.quantityLabel);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.albumOutput);
            this.Controls.Add(this.albumLabel);
            this.Controls.Add(this.inventoryListBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory Interface";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void label_search_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.ListBox inventoryListBox;
        private System.Windows.Forms.Label albumLabel;
        private System.Windows.Forms.Label albumOutput;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label quantityLabel;
        private System.Windows.Forms.Label artistLabel;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.Label priceOutput;
        private System.Windows.Forms.Label quantityOutput;
        private System.Windows.Forms.Label artistOutput;
        private System.Windows.Forms.Label categoryOutput;
        private System.Windows.Forms.Label searchLabel;
        private System.Windows.Forms.Button addItemButton;
        private System.Windows.Forms.Button removeItemButton;
        private System.Windows.Forms.Button restockItemButton;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label label_App_Title;
        private System.Windows.Forms.Button sellItemButton;
    }
}