﻿using System.Windows.Forms;
namespace MilestoneProject
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_addAlbum = new System.Windows.Forms.Label();
            this.label_addPrice = new System.Windows.Forms.Label();
            this.label_addQuantity = new System.Windows.Forms.Label();
            this.label_addArtist = new System.Windows.Forms.Label();
            this.label_addCategory = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.txt_addAlbum = new System.Windows.Forms.TextBox();
            this.txt_addPrice = new System.Windows.Forms.TextBox();
            this.txt_addQuantity = new System.Windows.Forms.TextBox();
            this.txt_addArtist = new System.Windows.Forms.TextBox();
            this.txt_addCategory = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label_addAlbum
            // 
            this.label_addAlbum.AutoSize = true;
            this.label_addAlbum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addAlbum.Location = new System.Drawing.Point(49, 66);
            this.label_addAlbum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_addAlbum.Name = "label_addAlbum";
            this.label_addAlbum.Size = new System.Drawing.Size(47, 17);
            this.label_addAlbum.TabIndex = 0;
            this.label_addAlbum.Text = "Album";
            // 
            // label_addPrice
            // 
            this.label_addPrice.AutoSize = true;
            this.label_addPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addPrice.Location = new System.Drawing.Point(56, 93);
            this.label_addPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_addPrice.Name = "label_addPrice";
            this.label_addPrice.Size = new System.Drawing.Size(40, 17);
            this.label_addPrice.TabIndex = 1;
            this.label_addPrice.Text = "Price";
            // 
            // label_addQuantity
            // 
            this.label_addQuantity.AutoSize = true;
            this.label_addQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addQuantity.Location = new System.Drawing.Point(35, 123);
            this.label_addQuantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_addQuantity.Name = "label_addQuantity";
            this.label_addQuantity.Size = new System.Drawing.Size(61, 17);
            this.label_addQuantity.TabIndex = 2;
            this.label_addQuantity.Text = "Quantity";
            // 
            // label_addArtist
            // 
            this.label_addArtist.AutoSize = true;
            this.label_addArtist.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addArtist.Location = new System.Drawing.Point(56, 39);
            this.label_addArtist.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_addArtist.Name = "label_addArtist";
            this.label_addArtist.Size = new System.Drawing.Size(40, 17);
            this.label_addArtist.TabIndex = 3;
            this.label_addArtist.Text = "Artist";
            // 
            // label_addCategory
            // 
            this.label_addCategory.AutoSize = true;
            this.label_addCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_addCategory.Location = new System.Drawing.Point(31, 12);
            this.label_addCategory.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_addCategory.Name = "label_addCategory";
            this.label_addCategory.Size = new System.Drawing.Size(65, 17);
            this.label_addCategory.TabIndex = 4;
            this.label_addCategory.Text = "Category";
            // 
            // btn_add
            // 
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.Location = new System.Drawing.Point(120, 153);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(134, 36);
            this.btn_add.TabIndex = 6;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // txt_addAlbum
            // 
            this.txt_addAlbum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addAlbum.Location = new System.Drawing.Point(100, 60);
            this.txt_addAlbum.Margin = new System.Windows.Forms.Padding(2);
            this.txt_addAlbum.Name = "txt_addAlbum";
            this.txt_addAlbum.Size = new System.Drawing.Size(175, 23);
            this.txt_addAlbum.TabIndex = 7;
            // 
            // txt_addPrice
            // 
            this.txt_addPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addPrice.Location = new System.Drawing.Point(100, 87);
            this.txt_addPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txt_addPrice.Name = "txt_addPrice";
            this.txt_addPrice.Size = new System.Drawing.Size(175, 23);
            this.txt_addPrice.TabIndex = 8;
            // 
            // txt_addQuantity
            // 
            this.txt_addQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addQuantity.Location = new System.Drawing.Point(100, 117);
            this.txt_addQuantity.Margin = new System.Windows.Forms.Padding(2);
            this.txt_addQuantity.Name = "txt_addQuantity";
            this.txt_addQuantity.Size = new System.Drawing.Size(175, 23);
            this.txt_addQuantity.TabIndex = 9;
            // 
            // txt_addArtist
            // 
            this.txt_addArtist.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addArtist.Location = new System.Drawing.Point(100, 33);
            this.txt_addArtist.Margin = new System.Windows.Forms.Padding(2);
            this.txt_addArtist.Name = "txt_addArtist";
            this.txt_addArtist.Size = new System.Drawing.Size(175, 23);
            this.txt_addArtist.TabIndex = 10;
            // 
            // txt_addCategory
            // 
            this.txt_addCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_addCategory.Location = new System.Drawing.Point(100, 6);
            this.txt_addCategory.Margin = new System.Windows.Forms.Padding(2);
            this.txt_addCategory.Name = "txt_addCategory";
            this.txt_addCategory.Size = new System.Drawing.Size(175, 23);
            this.txt_addCategory.TabIndex = 11;
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 199);
            this.Controls.Add(this.txt_addCategory);
            this.Controls.Add(this.txt_addArtist);
            this.Controls.Add(this.txt_addQuantity);
            this.Controls.Add(this.txt_addPrice);
            this.Controls.Add(this.txt_addAlbum);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.label_addCategory);
            this.Controls.Add(this.label_addArtist);
            this.Controls.Add(this.label_addQuantity);
            this.Controls.Add(this.label_addPrice);
            this.Controls.Add(this.label_addAlbum);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AddForm";
            this.Text = "Add Item";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        
        private Label label_addAlbum;
        private Label label_addPrice;
        private Label label_addQuantity;
        private Label label_addArtist;
        private Label label_addCategory;
        private Button btn_add;
        private TextBox txt_addAlbum;
        private TextBox txt_addPrice;
        private TextBox txt_addQuantity;
        private TextBox txt_addArtist;
        private TextBox txt_addCategory;
    }
}