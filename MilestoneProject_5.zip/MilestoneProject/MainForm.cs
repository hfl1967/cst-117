﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilestoneProject
{
    public partial class MainForm : Form
    {
        public InventoryManager newManager { get; set; } = new InventoryManager();
        private AddForm addItem;

        public MainForm()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // create new Manager and adds default items to inventory
            Inventory newItemOne = new Inventory("Americana", "Bruce Springsteen", "Nebraska", 19.99M, 3);
            Inventory newItemTwo = new Inventory("Metal", "Metallica", "Black Album", 15.99M, 2);
            Inventory newItemThree = new Inventory("Alt-Pop", "David Bowie", "Let's Dance", 19.99M, 1);
            Inventory newItemFour = new Inventory("Eighties", "The Cars", "Candy-O", 18.99M, 3);
            Inventory newItemFive = new Inventory("Grunge", "Nirvana", "Nevermind", 14.99M, 1);
            Inventory newItemSix = new Inventory("Classic Rock", "Led Zeppelin", "IV", 24.99M, 2);
            Inventory newItemSeven = new Inventory("Folk", "Bob Dylan", "Blood on the Tracks", 21.99M, 3);
            Inventory newItemEight = new Inventory("Folk", "Bob Dylan", "Highway 61 Revisited", 22.99M, 2);

            newManager.AddItem(newItemOne);
            newManager.AddItem(newItemTwo);
            newManager.AddItem(newItemThree);
            newManager.AddItem(newItemFour);
            newManager.AddItem(newItemFive);
            newManager.AddItem(newItemSix);
            newManager.AddItem(newItemSeven);
            newManager.AddItem(newItemEight);

            UpdateInventoryList();
            addItem = new AddForm(this, newManager);
        }

        // select an item in the inventoryListBox    
        private void InventoryListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (inventoryListBox.SelectedIndex != -1)
            {
                Inventory selectedItem = (Inventory)inventoryListBox.SelectedItem;
                UpdateSelected(selectedItem);
            }
            else
            {
                UpdateSelected();
            }
        }

        private void UpdateSelected()
        {
            albumOutput.Text = "";
            priceOutput.Text = "";
            quantityOutput.Text = "";
            artistOutput.Text = "";
            categoryOutput.Text = "";
        }

        private void UpdateSelected(Inventory selectedItem)
        {
            albumOutput.Text = selectedItem.Album;
            priceOutput.Text = selectedItem.Price.ToString("C2");
            quantityOutput.Text = selectedItem.Quantity.ToString();
            artistOutput.Text = selectedItem.Artist;
            categoryOutput.Text = selectedItem.Category;
        }
     
        public void UpdateInventoryList()
        {
            txt_search.Text = "";
            inventoryListBox.ClearSelected();
            inventoryListBox.Items.Clear();
            foreach (Inventory item in newManager.Inventory)
            {
                inventoryListBox.Items.Add(item);
            }
            UpdateSelected();
        }

        // updates list with passed parameters
        private void UpdateInventoryList(List<Inventory> inventory)
        {
            inventoryListBox.ClearSelected();
            inventoryListBox.Items.Clear();
            foreach ( Inventory item in inventory)
            {
                inventoryListBox.Items.Add(item);

            }
            UpdateSelected();
        }
        
        // searches inventory
        private void SearchTextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_search.Text))
            {
                UpdateInventoryList();
            }
            else
            {
                UpdateInventoryList(newManager.FindItems(txt_search.Text, txt_search.Text));
            }
        }

        // opens add form 
        private void AddItemButton_Click(object sender, EventArgs e)
        {
            addItem.ShowDialog();
        }

        // removes item from inventory list and updates list
        private void RemoveItemButton_Click(object sender, EventArgs e)
        {
            if (inventoryListBox.SelectedIndex != -1) // meaning an item is selected
            {
                Inventory selectedItem = (Inventory)inventoryListBox.SelectedItem;
                newManager.RemoveItem(selectedItem);
                UpdateInventoryList();
            }
        }
        
        // restocks item to default inventory list 
        private void RestockItemButton_Click(object sender, EventArgs e)
        {
            if(inventoryListBox.SelectedIndex != -1)
            {
                Inventory selectedItem = (Inventory)inventoryListBox.SelectedItem;
                newManager.RestockItem(selectedItem);
                UpdateSelected(selectedItem);
            }
        }

        private void SellItemButton_Click(object sender, EventArgs e)
        {
            if (inventoryListBox.SelectedIndex != -1)
            {
                Inventory selectedItem = (Inventory)inventoryListBox.SelectedItem;
                newManager.SellItem(selectedItem);
                UpdateSelected(selectedItem);
            }
        }
    }
}
