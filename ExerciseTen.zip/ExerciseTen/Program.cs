﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseTen
{
    class Program
    {
        static void Main(string[] args)
        {
            // set counter for chars
            int counter = 0;

            // define delimiters
            char[] delimiterChars = { ' ', ',', '!' };

            // init a StreamReader file
            StreamReader inputFile;

            // test string 
            string inputString = "";

            // open the file and get a StreamReader object
            inputFile = File.OpenText("GivenTextFile.txt");

            // read the string into memory
            while (!inputFile.EndOfStream)
            {
                inputString = inputFile.ReadLine();
            }
            
            // close the file
            inputFile.Close();

            // split input string separated by spaces or punctuation, remove dupes
            string[] splitWords = inputString.Split(delimiterChars, System.StringSplitOptions.RemoveEmptyEntries);

            // find out if a word ends with t or e, if so, add to counter
            foreach (string word in splitWords)
            {
                if (word.EndsWith("t") == true)
                {
                    counter++;
                }
                else if (word.EndsWith("T") == true)
                {
                    counter++;
                }
                else if (word.EndsWith("e") == true)
                {
                    counter++;
                }
                else if (word.EndsWith("E") == true)
                {
                    counter++;
                }
                else
                {
                    // do nothing, keep going
                }
            }
            Console.WriteLine("There are " + counter + " words that end in t or e");
            Console.WriteLine("Press any key to continue . . .");
            Console.ReadKey();

        }
    }
}
