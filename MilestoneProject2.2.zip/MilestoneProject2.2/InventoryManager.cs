﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilestoneProject
{
    public class InventoryManager
    {
        public List<Inventory> Inventory { get; private set; } = new List<Inventory>();

        // adds item to inventory after checking if item exists
        public Inventory AddItem(Inventory item)
        {
            if (ContainsItem(item))
            {
                Inventory foundItem = FindItem(item);
                foundItem.Quantity += item.Quantity;
                return foundItem;
            }
            else
            {
                Inventory.Add(item);
                return item;
            }
        }

        // tells us whether or not item is a valid inventory item
        public bool ContainsItem(Inventory item)
        {
            return Inventory.Contains(item);
        }

        // returns found inventory object
        public Inventory FindItem(Inventory item)
        {
            return Inventory.Find(x => x.Equals(item));
        }

        // looks for album or artist in list, creates new list with results
        public List<Inventory> FindItems(string album, string artist)
        {
            List<Inventory> searchResults = new List<Inventory>();
            return Inventory.FindAll(x => x.Equals(album, artist));
        }

        // remove an item from the inventory
        public bool RemoveItem(Inventory item)
        {
            if (ContainsItem(item))
            {
                Inventory.Remove(item);
                return true;
            }
            else
            {
                return false;
            }
        }

        // sell one
        public void SellItem(Inventory item)
        {
            Inventory inventoryItem = FindItem(item);
            inventoryItem.Quantity -= 1;
        }

        // adds 5 (default restock qty)
        public void RestockItem(Inventory item)
        {
            Inventory inventoryItem = FindItem(item);
            inventoryItem.Quantity += 5;
        }
    }
}
