﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilestoneProject
{
#pragma warning disable CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    public class Inventory
#pragma warning restore CS0659 // Type overrides Object.Equals(object o) but does not override Object.GetHashCode()
    {
        // getters and setters
        public string Category { get; set; }
        public string Artist { get; set; }
        public string Album { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }

        // constructor
        public Inventory(string category, string artist, string album, decimal price, int quantity)
        {
            this.Category = category;
            this.Artist = artist;
            this.Album = album;
            this.Price = price;
            this.Quantity = quantity;
        }

        // check to see if item == item in inventory
        public override bool Equals(object obj)
        {
            return (obj is Inventory) && ((Inventory)obj).Album == Album;
        }

        // check to see if item in inventory matches parameters via search box, accounts for case
        public bool Equals(string album, string artist)
        {
            return Album.ToLower().Contains(album.ToLower()) || Artist.ToLower().Contains(artist.ToLower());
        }

        // pretty print for outputlistbox
        public override string ToString()
        {
            return "Artist: " + Artist + ", \n Album: " + Album;

        }

    }
}
