﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilestoneProject
{
    public partial class AddForm : Form
    {
        MainForm inventoryForm;
        InventoryManager newManager;

        public AddForm(MainForm form2, InventoryManager inventoryManager)
        {
            InitializeComponent();
            inventoryForm = form2;
            newManager = inventoryManager;
        }

        private bool CheckForErrors()
        {
            return (
                !string.IsNullOrWhiteSpace(txt_addAlbum.Text) &&
                decimal.TryParse(txt_addPrice.Text, out decimal price)) &&
                int.TryParse(txt_addQuantity.Text, out int quantity) &&
                !string.IsNullOrWhiteSpace(txt_addArtist.Text) &&
                !string.IsNullOrWhiteSpace(txt_addCategory.Text);
        }

        // after clicking 'add' on the AddForm
        private void AddButton_Click(object sender, EventArgs e)
        {
            if (CheckForErrors())
            {
                // constructor
                Inventory newItem = new Inventory(txt_addCategory.Text, txt_addArtist.Text, 
                    txt_addAlbum.Text, decimal.Parse(txt_addPrice.Text), int.Parse(txt_addQuantity.Text));

                // add new item to manager
                newManager.AddItem(newItem);
                inventoryForm.UpdateInventoryList();
                this.Hide();
                txt_addAlbum.Text = "";
                txt_addPrice.Text = "";
                txt_addQuantity.Text = "";
                txt_addArtist.Text = "";
                txt_addCategory.Text = "";
            }
            else
            {
                MessageBox.Show("Invalid input.");
            }
        }
    }
}
